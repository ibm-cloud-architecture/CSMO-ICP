#!/bin/sh
for i in `cat alerts.txt`
do
cat <<EOF > $i.yml
apiVersion: monitoringcontroller.cloud.ibm.com/v1
kind: AlertRule
metadata:
  name: $i
spec:
  enabled: true
  data: |-
    groups:
      - name: $i.rules
        rules:
          - alert: $i
EOF
done
